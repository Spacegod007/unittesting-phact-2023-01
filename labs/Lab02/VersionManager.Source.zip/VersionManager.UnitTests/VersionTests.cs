using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace VersionManager.UnitTests
{

  [TestCategory("Dynamic")] 
  [TestClass]
  public class DynamicTests
  {
    [Priority(1)]
    [TestProperty("Flakiness", "High")]
    [TestMethod]
    public void GetVersion_Expect_10_0()
    {
      Accentient.VersionManager vm = new Accentient.VersionManager();
      string expected = "10.0";
      string actual = vm.GetVersion();
      Assert.AreEqual(expected, actual);
    }
    [TestCategory("Friendly")]
    [Priority(1)]
    [TestProperty("Flakiness", "High")]
    [TestMethod()]
    public void GetVersion_Expect_FriendlyName()
    {
      Accentient.VersionManager vm = new Accentient.VersionManager();
      string actual = vm.GetVersionName();
      Assert.AreEqual("Windows 10/Server 2016/Server 2019", actual);
    }
  }

  [TestClass]
  public class StaticTests
  {
    [TestCategory("Friendly"), TestCategory("Static")]
    [TestProperty("Flakiness", "Low")]
    [TestMethod()]
    public void GetVersion_6_0_Expect_WindowsVistaServer2008()
    {
      Accentient.VersionManager vm = new Accentient.VersionManager();
      Assert.AreEqual("Windows Vista/Server 2008", vm.GetVersionName(6, 0));
    }
    [TestCategory("Friendly"), TestCategory("Static")]
    [TestProperty("Flakiness", "Low")]
    [TestMethod()]
    public void GetVersion_5_2_Expect_WindowsXP64Server2003()
    {
      Accentient.VersionManager vm = new Accentient.VersionManager();
      Assert.AreEqual("Windows XP-64/Server 2003", vm.GetVersionName(5, 2));
    }
    [TestCategory("Friendly"), TestCategory("Client"), TestCategory("Static")]
    [TestProperty("Flakiness", "Low")]
    [Owner("Richard")]
    [TestMethod()]
    public void GetVersion_5_1_Expect_WindowsXP()
    {
      Accentient.VersionManager vm = new Accentient.VersionManager();
      Assert.AreEqual("Windows XP", vm.GetVersionName(5, 1));
    }

    [TestCategory("Friendly"), TestCategory("Client"), TestCategory("Static")]
    [TestProperty("Flakiness", "High")]
    [TestMethod()]
    public void GetVersion_12_0_Expect_WindowsPink()
    {
      Accentient.VersionManager vm = new Accentient.VersionManager();
      Assert.AreEqual("Windows Pink", vm.GetVersionName(12, 0));
    }

  }
}
