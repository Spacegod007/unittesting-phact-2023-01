﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NSubstitute;

namespace CoolCalc
{
  [TestClass]
  public class CalculatorTest
  {
    [TestMethod]
    public void Should_Call_PerformOperation_When_Invoking_Execute()
    {
      Calculator calc = Substitute.For<Calculator>(new Add());
      calc.Execute(7,8).Returns(15);
      Assert.AreEqual(15, calc.Execute(7,8));

      calc.Received().Execute(7,8);
      calc.DidNotReceive().Execute(8,7);
      calc.DidNotReceive().Execute(21,21);
    }
  }
}
